document.addEventListener('DOMContentLoaded', function() {
  console.log('Project index.html is ready!');
});